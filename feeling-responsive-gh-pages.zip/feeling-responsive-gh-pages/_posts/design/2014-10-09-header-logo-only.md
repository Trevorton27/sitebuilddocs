---
layout: page
title:  "Header With Logo Only"
subheadline:  "Headers With Style"
teaser: "Feeling Responsive allows you to use all kinds of headers. This is the default mode. It shows a header just with your logo on the standard background."
categories:
    - design
tags:
    - design
    - background color
    - header
---
No front matter code needed.
<!--more-->

### All Header-Styles 
{: .t60 }

{% include list-posts tag='header' %}