---
title: Another Test Post Within Subdirectory
foo: bar
---

# Another Test Post within `_posts/more posts/some more posts`
