---
title: Post Within Subdirectory
foo: bar
---

# Test Post within `_posts/more posts`
