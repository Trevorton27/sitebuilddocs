---
title: Rover
breed: Golden Retriever
---
