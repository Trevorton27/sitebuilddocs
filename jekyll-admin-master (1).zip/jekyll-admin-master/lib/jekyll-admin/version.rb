module JekyllAdmin
  VERSION = "0.8.0".freeze
end
