import {chalkSuccess} from './chalkConfig';

/* eslint-disable no-console */

console.log(chalkSuccess('Starting Jekyll Admin in dev mode...'));
