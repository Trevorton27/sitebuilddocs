export const VERSION = 'v0.8.0';
export const ADMIN_PREFIX = '/admin';
