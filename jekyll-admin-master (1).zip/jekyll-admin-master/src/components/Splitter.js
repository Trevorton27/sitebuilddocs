import React from 'react';

const Splitter = () => <div className="splitter" />;

export default Splitter;
