---
title: Constants
---

## Action Types

Stores all of the action creators' names

## Lang

Stores the language specific files. Selected language strings are exported from `index.js`.

This allows us to control all of the language specific strings in a single place and also will help us localize the admin panel in the future.

## API

Stores all of the API endpoints
